import openai

# Load your API key from an environment variable or secret management service

openai.api_key = "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" ##YOUR_API_KEY
model_engine="text-davinci-003"
ask = input("Faca a sua perguta? ") #Variavel para digitar a pergunta no console
prompt= "" #Variavel para pergunta 

response= openai.Completion.create(
    engine=model_engine,
    prompt=ask,
    max_tokens=2048,
    n=3,
    stop=['---'],
    temperature=0.9,
)

for result in response.choices:
    print(result.text)
